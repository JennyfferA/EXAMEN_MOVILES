package com.example.examen.data.Contrato

import androidx.room.Entity
import androidx.room.PrimaryKey



@Entity(tableName = "Contrato")
data class Contrato(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val tipo: String,
    val detalle: String,
    val imagenUri: Int,
    val sueldo: Double
)

