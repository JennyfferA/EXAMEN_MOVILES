package com.example.examen.data.Contrato

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow


@Dao
interface ContratoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContrato(direccion: Contrato)

    @Query("SELECT * FROM Contrato")
    fun getAllContrato(): Flow<List<Contrato>>

    @Query("SELECT * FROM Contrato WHERE id = :id")
    suspend fun getContratoById(id: Int): Contrato?

    @Query("DELETE FROM Contrato WHERE id = :id")
    suspend fun deleteContratoById(id: Int)
}
