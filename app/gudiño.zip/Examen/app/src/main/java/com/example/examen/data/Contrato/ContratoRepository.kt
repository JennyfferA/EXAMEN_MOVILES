import com.example.examen.data.Contrato.AppDatabase
import com.example.examen.data.Contrato.Contrato
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn

class ContratoRepository(private val db: AppDatabase) {

    // Devuelve directamente el Flow<List<Direcion>> desde el DAO
    fun getAllContrato(): Flow<List<Contrato>> {
        return db.direccionDao().getAllContrato()
            .flowOn(Dispatchers.IO) // Asegurarse de que se ejecute en IO thread
    }

    suspend fun insertContrato(direccion: Contrato) {
        db.direccionDao().insertContrato(direccion)
    }

    suspend fun getContratoById(id: Int): Contrato? {
        return db.direccionDao().getContratoById(id)
    }

    suspend fun deleteContratoById(id: Int) {
        db.direccionDao().deleteContratoById(id)
    }
}
