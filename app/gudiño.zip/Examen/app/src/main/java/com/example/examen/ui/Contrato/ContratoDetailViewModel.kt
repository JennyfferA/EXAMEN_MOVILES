package com.example.examen.ui.Contrato

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.examen.data.Contrato.Contrato
import ContratoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ContratoDetailViewModel(
    private val contratoRepository: ContratoRepository
) : ViewModel() {

    private val _contrato = MutableStateFlow<Contrato?>(null)
    val contrato: StateFlow<Contrato?> = _contrato

    fun loadContrato(id: Int) {
        viewModelScope.launch {
            _contrato.value = contratoRepository.getContratoById(id)
        }
    }

    fun deleteContrato(id: Int) {
        viewModelScope.launch {
            contratoRepository.deleteContratoById(id)
        }
    }
}
