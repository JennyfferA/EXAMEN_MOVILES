package com.example.examen.ui.Contrato

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.inventory.ui.AppViewModelProvider


import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import com.example.examen.ui.theme.Purple40
import com.example.examen.ui.theme.PurpleGrey40

@Composable
fun ContratoListScreen(
    onContratoClick: (Int) -> Unit, // Callback para navegar a los detalles del contrato
    viewModel: ContratoViewModel = viewModel(factory = AppViewModelProvider.Factory) // Obtención del ViewModel
) {
    val contratos = viewModel.contratos.collectAsState(initial = emptyList()).value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(color = Purple40),
        horizontalAlignment = Alignment.CenterHorizontally // Centrar el contenido horizontalmente
    ) {
        Text(
            text = "Contratos",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 16.dp),
            color = PurpleGrey40
        )

        // Lista de contratos
        contratos.forEach { contrato ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable { onContratoClick(contrato.id) } // Navegar al hacer clic
                    .border(1.dp, color = PurpleGrey40) // Borde entre elementos
                    .padding(16.dp) // Padding interno para el texto
            ) {
                Text(
                    text = contrato.tipo,
                    style = MaterialTheme.typography.bodyLarge,
                    color = PurpleGrey40
                )
            }
        }
    }
}
