package com.example.examen.ui.Contrato

import ContratoRepository
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.examen.data.Contrato.Contrato
import com.example.inventory.R
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ContratoViewModel(
    private val contratoRepository: ContratoRepository
) : ViewModel() {

    // Cambiar cursos a contratos para reflejar el cambio
    val contratos: StateFlow<List<Contrato>> = contratoRepository.getAllContrato()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Lazily,
            initialValue = emptyList()
        )

    init {
        // Llamar a la función para insertar contratos al inicializar el ViewModel
        viewModelScope.launch {
            insertInitialContratos()
        }
    }

    private suspend fun insertInitialContratos() {
        // Comprobar si ya hay contratos antes de insertar
        if (contratos.value.isEmpty()) {
                val initialContratos = listOf(
                    Contrato(tipo = "Contratista", detalle = "Contrato por servicios de limpieza", imagenUri = R.drawable.culinary, sueldo = 1000.0),
                    Contrato(tipo = "Freelancer", detalle = "Desarrollo de software", imagenUri = R.drawable.design, sueldo = 1500.0),
                    Contrato(tipo = "Consultor", detalle = "Asesoría en marketing", imagenUri = R.drawable.drawing, sueldo = 1200.0),
                    Contrato(tipo = "Proveedor", detalle = "Suministro de material de oficina", imagenUri = R.drawable.ecology, sueldo = 800.0),
                    Contrato(tipo = "Empleado", detalle = "Contrato a tiempo completo", imagenUri = R.drawable.engineering, sueldo = 2000.0)
                )

            // Insertar los contratos iniciales en la base de datos
            initialContratos.forEach { contrato ->
                contratoRepository.insertContrato(contrato)
            }
        }
    }
}
